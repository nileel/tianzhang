using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using UnityEngine;
using UnityEngine.Rendering;
using UniGLTF;
using UniVRM10;

public class SleevePlayer : MonoBehaviour
{
    readonly ComparisonRig[] rigs=new ComparisonRig[2];
    readonly Camera[] cameras=new Camera[2];
    Motions motion;
    int which,frame;
    float accumulator;
    bool playing,side,capturing;
    string status="读取模型与动作…", output;
    Font font;
    GUIStyle heading, body;
    ClipData Clip => motion.clips[which];
    async void Start()
    {
        try {
            System.Threading.Thread.CurrentThread.CurrentCulture=System.Globalization.CultureInfo.InvariantCulture;
            Application.runInBackground=true;
            Application.targetFrameRate=60;
            QualitySettings.vSyncCount=0;
            QualitySettings.skinWeights=SkinWeights.Unlimited;
            var args=Environment.GetCommandLineArgs();
            int ci=Array.IndexOf(args,"-capture");
            capturing=ci>=0;
            output=capturing?args[ci+1]:Application.persistentDataPath;
            var di=Array.IndexOf(args,"-dataset");
            var folder=di<0?Application.streamingAssetsPath:args[di+1];
            motion=JsonUtility.FromJson<Motions>(File.ReadAllText(Path.Combine(folder,"motion.json")));
            if(motion.landmarks==null) motion.landmarks=JsonUtility.FromJson<Motions>(File.ReadAllText(Path.Combine(folder,"landmarks.json"))).landmarks;
            if(motion.landmarks==null || motion.landmarks.Length<4) throw new Exception("Missing cloth landmarks");
            Debug.Log("Loading source model "+Path.Combine(folder,"model.vrm"));
            for(int i=0;i<2;i++) {
                var vrm=await Vrm10.LoadPathAsync(Path.Combine(folder,"model.vrm"),canLoadVrm0X:false,controlRigGenerationOption:ControlRigGenerationOption.None,
                    awaitCaller:new ImmediateCaller(),springboneRuntime:new Vrm10FastSpringboneRuntimeStandalone());
                rigs[i]=new ComparisonRig(vrm,motion,9+i);
                Debug.Log("model="+i+" joints="+string.Join(",",vrm.SpringBone.Springs.Select(g=>g.Name+"("+string.Join("/",g.Joints.Select(j=>j.name))+")"))+
                    " materials="+string.Join(",",rigs[i].Renderers.SelectMany(r=>r.sharedMaterials.Select(m=>m.shader.name))));
                cameras[i]=new GameObject("对照机位"+i).AddComponent<Camera>();
                var camera=cameras[i];
                camera.clearFlags=CameraClearFlags.SolidColor;
                camera.backgroundColor=new Color(.72f,.74f,.76f);
                camera.orthographic=true;
                camera.orthographicSize=capturing?1.02f:Mathf.Max(1.02f,1.02f*Screen.height*.82f/(Screen.width*.5f));
                camera.cullingMask=1<<(9+i);
                camera.nearClipPlane=.05f;
                camera.farClipPlane=12f;
                camera.rect=new Rect(i*.5f,.12f,.5f,.82f);
                camera.allowHDR=false;
                camera.enabled=!capturing;
            }
            var ground=new GameObject("全画布").AddComponent<Camera>();
            ground.depth=-2;
            ground.clearFlags=CameraClearFlags.SolidColor;
            ground.backgroundColor=new Color(.12f,.15f,.19f);
            ground.cullingMask=0;
            RenderSettings.ambientMode=AmbientMode.Flat;
            RenderSettings.ambientLight=new Color(.71f,.72f,.73f);
            var light=new GameObject("柔光").AddComponent<Light>();
            light.type=LightType.Directional; light.intensity=1.05f;
            Vector3 lightDir=rigs[0].Basis.MultiplyVector(new Vector3(.38f,-.65f,1));
            light.transform.rotation=Quaternion.LookRotation(-lightDir);
            font=Font.CreateDynamicFontFromOSFont("Microsoft YaHei",18);
            if(capturing) {Directory.CreateDirectory(output);StartCoroutine(Capture());}
            else {Select("stop");status=null;Debug.Log("PREVIEW_READY paused stop frame zero");}
        } catch(Exception ex) {Fail(ex);}
    }
    void Fail(Exception ex) {
        Debug.LogException(ex); status=ex.Message;
        if(capturing) {File.WriteAllText(Path.Combine(output,"failed.txt"),ex.ToString()); Application.Quit(2);}
    }
    void View(bool sideView)
    {
        side=sideView;
        var center=rigs[0].FromSource(new Vector3(0,0,.97f));
        var direction=rigs[0].Basis.MultiplyVector(side ? Vector3.right : Vector3.down);
        var up=rigs[0].Basis.MultiplyVector(Vector3.forward);
        foreach(var c in cameras) {
            c.transform.position=center+direction*3.4f;
            c.transform.rotation=Quaternion.LookRotation(-direction,up);
        }
    }
    void Select(string name)
    {
        which=Array.FindIndex(motion.clips,c=>c.name==name);
        if(which<0 || Clip.fps!=60) throw new Exception("Missing 60Hz clip "+name);
        foreach(var r in rigs) {r.Restore();r.Apply(Clip.frames[0]);}
        // Settle in the first actual pose before starting each trial.
        for(int i=0;i<90;i++) rigs[1].Step();
        frame=0;accumulator=0;View(side);
    }
    void Tick()
    {
        if(frame+1>=Clip.frames.Length) {Select(Clip.name);return;}
        frame++;
        foreach(var r in rigs)r.Apply(Clip.frames[frame]);
        rigs[1].Step();
    }
    void Update()
    {
        if(status!=null || !playing || capturing) return;
        accumulator+=Time.unscaledDeltaTime;
        while(accumulator>=1f/60) {accumulator-=1f/60; Tick();}
    }
    void OnGUI()
    {
        if(capturing)return;
        var h=Screen.height; var w=Screen.width;
        if(font!=null) GUI.skin.font=font;
        heading??=new GUIStyle(GUI.skin.label){alignment=TextAnchor.MiddleCenter,fontSize=20,fontStyle=FontStyle.Bold};
        body??=new GUIStyle(GUI.skin.button){fontSize=16};
        GUI.Label(new Rect(0,0,w*.5f,h*.06f),"物理关",heading);
        GUI.Label(new Rect(w*.5f,0,w*.5f,h*.06f),"物理开",heading);
        if(status!=null) {GUI.Label(new Rect(16,40,w-32,70),status,heading);return;}
        GUILayout.BeginArea(new Rect(12,h*.885f,w-24,h*.11f));
        GUILayout.BeginHorizontal();GUILayout.FlexibleSpace();
        if(GUILayout.Button(playing?"暂停":"播放",body,GUILayout.Width(92)))playing=!playing;
        if(GUILayout.Button("重播",body,GUILayout.Width(68)))Select(Clip.name);
        foreach(var pair in new[]{("stop","抬臂急停"),("walk","原版走路"),("attack","原版攻击")})
            if(GUILayout.Button((Clip.name==pair.Item1?"● ":"")+pair.Item2,body,GUILayout.Width(112)))Select(pair.Item1);
        if(GUILayout.Button(side?"切到正面":"切到侧面",body,GUILayout.Width(104)))View(!side);
        GUILayout.FlexibleSpace();GUILayout.EndHorizontal();
        GUILayout.Label((side?"侧面":"正面")+"   ·   "+(frame/60f).ToString("F2")+" 秒   ·   "+frame+" / "+(Clip.frames.Length-1)+"   ·   60 Hz",new GUIStyle(GUI.skin.label){alignment=TextAnchor.MiddleCenter,fontSize=15});
        GUILayout.EndArea();
    }
    IEnumerator Capture()
    {
        yield return null;
        var it=CaptureFrames();
        while(true) {
            bool more;
            try {more=it.MoveNext();}catch(Exception ex){Fail(ex);yield break;}
            if(!more)yield break;
            yield return it.Current;
        }
    }
    IEnumerator CaptureFrames()
    {
        var readback=rigs.Select(r=>new ClothReadback(r,motion.landmarks)).ToArray();
        using var points=new StreamWriter(Path.Combine(output,"cloth-points.csv"));
        using var edges=new StreamWriter(Path.Combine(output,"cloth-edges.csv"));
        points.WriteLine("clip,frame,physics,landmark,blenderX,blenderY,blenderZ,vertex");
        edges.WriteLine("clip,frame,physics,side,renderer,vertexA,vertexB,restLength,posedLength,growth,restAx,restAy,restAz,restBx,restBy,restBz,posedAx,posedAy,posedAz,posedBx,posedBy,posedBz");
        const int width=624,height=596;
        var rt=new RenderTexture(width,height,24,RenderTextureFormat.ARGB32){antiAliasing=2};
        rt.Create();
        var plate=new Texture2D(width*2,height,TextureFormat.RGB24,false);
        foreach(var name in new[]{"stop","walk","attack"}) {
            Select(name);
            foreach(var s in new[]{"front","side"})Directory.CreateDirectory(Path.Combine(output,name+"-"+s));
            for(int f=0;f<Clip.frames.Length;f++) {
                if(f>0) Tick();
                for(int i=0;i<2;i++)readback[i].Record(points,edges,Clip.name,f,i);
                if(f%2!=0) continue;
                // Unity updates GPU-skinned buffers once per player frame. Advance
                // the rendering frame after the CPU pose, before capturing either view.
                yield return null;
                foreach(var view in new[]{"front","side"}) {
                    View(view=="side");
                    foreach(var c in cameras) {
                        c.targetTexture=rt; c.rect=new Rect(0,0,1,1); c.aspect=(float)width/height;
                        c.Render();
                        RenderTexture.active=rt;
                        plate.ReadPixels(new Rect(0,0,width,height),width*Array.IndexOf(cameras,c),0,false);
                        RenderTexture.active=null;
                        c.targetTexture=null;
                    }
                    plate.Apply(false,false);
                    File.WriteAllBytes(Path.Combine(output,name+"-"+view,(f/2).ToString("0000")+".png"),plate.EncodeToPNG());
                }
            }
            points.Flush();edges.Flush();
            Debug.Log("CAPTURED "+name+" frames="+Clip.frames.Length);
        }
        rt.Release();Destroy(rt);Destroy(plate);
        File.WriteAllText(Path.Combine(output,"completed.txt"),DateTime.Now.ToString("s"));
        Application.Quit(0);
    }
}
