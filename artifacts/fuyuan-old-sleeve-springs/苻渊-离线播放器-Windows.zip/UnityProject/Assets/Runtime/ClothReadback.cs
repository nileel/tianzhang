using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using UnityEngine;

public class ClothReadback
{
    class Surface
    {
        public SkinnedMeshRenderer renderer;
        public readonly Mesh baked = new Mesh();
        public readonly List<Vector3> points = new List<Vector3>();
        public Vector3[] rest;
        public readonly List<Edge> edges = new List<Edge>();
        public void Bake()
        {
            renderer.BakeMesh(baked);
            baked.GetVertices(points);
            var matrix = renderer.transform.localToWorldMatrix;
            for (int i=0;i<points.Count;i++) points[i]=matrix.MultiplyPoint3x4(points[i]);
        }
    }
    struct Edge {public int a,b,side; public float length;}
    struct Marker { public Surface surface; public int i; public Landmark landmark; }
    readonly ComparisonRig rig;
    readonly List<Surface> surfaces = new List<Surface>();
    readonly Marker[] markers;
    public ClothReadback(ComparisonRig model, Landmark[] landmarks)
    {
        rig=model;
        foreach(var r in rig.Renderers) {
            var s=new Surface{renderer=r};
            s.Bake(); s.rest=s.points.Select(rig.ToSource).ToArray();
            var seen=new HashSet<long>();
            var ind=r.sharedMesh.triangles;
            for(int k=0;k<ind.Length;k+=3)
            for(int l=0;l<3;l++) {
                int a=ind[k+l],b=ind[k+(l+1)%3];
                if(a>b) (a,b)=(b,a);
                long key=((long)a<<32)|(uint)b;
                if(!seen.Add(key)) continue;
                var p=s.rest[a]; var q=s.rest[b];
                bool InSleeve(Vector3 v) => Mathf.Abs(v.x)>.38f && Mathf.Abs(v.x)<.78f && v.z>.55f && v.z<1.32f;
                if(!InSleeve(p) || !InSleeve(q) || p.x*q.x<=0) continue;
                var len=Vector3.Distance(p,q);
                if(len>=.001f) s.edges.Add(new Edge{a=a,b=b,side=p.x<0?0:1,length=len});
            }
            surfaces.Add(s);
        }
        markers = landmarks.Select(l => {
            var p=ComparisonRig.Read(l.p,0); float best=float.PositiveInfinity; var m=new Marker{landmark=l};
            foreach(var s in surfaces) for(int i=0;i<s.rest.Length;i++) {
                float d=(s.rest[i]-p).sqrMagnitude;
                if (d<best) {best=d;m.surface=s;m.i=i;}
            }
            Debug.Log("Marker "+l.name+" mesh="+m.surface.renderer.name+" vertex="+m.i+" rest mismatch mm="+Mathf.Sqrt(best)*1000);
            if (best>.002f*.002f) throw new Exception("Rest vertex mismatch >2mm: "+l.name);
            return m;
        }).ToArray();
    }
    public void Record(StreamWriter points,StreamWriter edges,string clip,int frame,int ab)
    {
        foreach(var s in surfaces) s.Bake();
        foreach(var m in markers) {
            var p=rig.ToSource(m.surface.points[m.i]);
            points.WriteLine(FormattableString.Invariant($"{clip},{frame},{ab},{m.landmark.name},{p.x:R},{p.y:R},{p.z:R},{m.i}"));
        }
        var largest=new float[]{float.NegativeInfinity,float.NegativeInfinity};
        var rows=new string[2];
        foreach(var s in surfaces) foreach(var e in s.edges) {
            float len=Vector3.Distance(s.points[e.a],s.points[e.b]);
            float growth=len-e.length;
            if(growth<=largest[e.side])continue;
            largest[e.side]=growth;
            var p=s.rest[e.a]; var q=s.rest[e.b]; var at=rig.ToSource(s.points[e.a]); var bt=rig.ToSource(s.points[e.b]);
            rows[e.side]=FormattableString.Invariant($"{clip},{frame},{ab},{(e.side==0?"L":"R")},{s.renderer.name},{e.a},{e.b},{e.length:R},{len:R},{growth:R},{p.x:R},{p.y:R},{p.z:R},{q.x:R},{q.y:R},{q.z:R},{at.x:R},{at.y:R},{at.z:R},{bt.x:R},{bt.y:R},{bt.z:R}");
        }
        foreach(var line in rows) if(line!=null) edges.WriteLine(line);
    }
}
