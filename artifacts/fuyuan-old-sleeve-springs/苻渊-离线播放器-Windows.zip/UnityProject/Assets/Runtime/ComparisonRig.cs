using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UniVRM10;

[Serializable] public class Motions { public string[] bones; public float[] restP; public ClipData[] clips; public Landmark[] landmarks; }
[Serializable] public class ClipData { public string name; public int fps, stopFrame; public PoseData[] frames; }
[Serializable] public class PoseData { public float[] p, q; }
[Serializable] public class Landmark { public string name; public float[] p; }

public class ComparisonRig
{
    public readonly Vrm10Instance Vrm;
    public readonly SkinnedMeshRenderer[] Renderers;
    public Matrix4x4 Basis;
    public Vector3 Origin;
    public float MaxRestError;
    readonly Transform[] body;
    readonly Quaternion[] restRot;
    readonly Vector3[] restPos;
    readonly Motions motion;

    public static Vector3 Read(float[] a,int n) => new Vector3(a[n], a[n+1], a[n+2]);
    public ComparisonRig(Vrm10Instance instance, Motions data, int layer)
    {
        Vrm = instance;
        Vrm.UpdateType = Vrm10Instance.UpdateTypes.None;
        var animator = Vrm.GetComponent<Animator>();
        if (animator != null) animator.enabled = false;
        var all = Vrm.GetComponentsInChildren<Transform>(true);
        foreach (var t in all) t.gameObject.layer = layer;
        Renderers = Vrm.GetComponentsInChildren<SkinnedMeshRenderer>(true);
        foreach (var r in Renderers) r.updateWhenOffscreen = true;
        motion = data;
        body = data.bones.Select(n => all.Single(t => t.name == n)).ToArray();
        restPos = body.Select(t => t.position).ToArray();
        restRot = body.Select(t => t.rotation).ToArray();
        FindBasis();
        Debug.Log("Rest RMS fit max mm="+MaxRestError*1000f+" origin="+Origin.ToString("F6")+" axes="+Basis);
        if (MaxRestError > 0.001f)
            throw new InvalidOperationException("Rest joint fit exceeds 1mm; inspect source/import transforms.");
    }
    void FindBasis()
    {
        var best = double.PositiveInfinity;
        var axes = new[]{Vector3.right, Vector3.up, Vector3.forward};
        for(int i=0;i<3;i++) for(int j=0;j<3;j++) if(i!=j)
        for(int x=-1;x<=1;x+=2) for(int y=-1;y<=1;y+=2) for(int z=-1;z<=1;z+=2)
        {
            var m = Matrix4x4.identity;
            m.SetColumn(0,axes[i]*x); m.SetColumn(1,axes[j]*y); m.SetColumn(2,axes[3-i-j]*z);
            if(m.determinant>0f) continue;
            var origin=Vector3.zero;
            for(int b=0;b<body.Length;b++) origin+=restPos[b]-m.MultiplyVector(Read(motion.restP,b*3));
            origin/=body.Length;
            double ss=0; float max=0;
            for(int b=0;b<body.Length;b++) {
                float d=(origin+m.MultiplyVector(Read(motion.restP,b*3))-restPos[b]).magnitude;
                ss+=d*d; max=Mathf.Max(max,d);
            }
            if(ss<best) {best=ss; Basis=m; Origin=origin; MaxRestError=max;}
        }
    }
    public Vector3 ToSource(Vector3 world) => Basis.transpose.MultiplyVector(world-Origin);
    public Vector3 FromSource(Vector3 point) => Origin+Basis.MultiplyVector(point);
    public void Apply(PoseData pose)
    {
        for(int i=0;i<body.Length;i++) {
            int p=i*3,q=i*4;
            var v=-Basis.MultiplyVector(Read(pose.q,q));
            var rotation=new Quaternion(v.x,v.y,v.z,pose.q[q+3])*restRot[i];
            var position=restPos[i]+Basis.MultiplyVector(Read(pose.p,p)-Read(motion.restP,p));
            body[i].SetPositionAndRotation(position,rotation);
        }
    }
    public void Restore()
    {
        for(int i=0;i<body.Length;i++) body[i].SetPositionAndRotation(restPos[i],restRot[i]);
        Vrm.Runtime.SpringBone.RestoreInitialTransform();
    }
    public void Step() => Vrm.Runtime.SpringBone.Process(1f/60f);
}
