using System;
using System.IO;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEditor.Build.Reporting;
using UnityEngine;

public static class BuildComparison
{
    public static void Build()
    {
        const string scenePath="Assets/SleeveTest.unity";
        var scene=EditorSceneManager.NewScene(NewSceneSetup.EmptyScene,NewSceneMode.Single);
        new GameObject("苻渊 · 旧宽袖对照").AddComponent<SleevePlayer>();
        EditorSceneManager.SaveScene(scene,scenePath);
        PlayerSettings.productName="苻渊旧宽袖 · 弹簧实测";
        PlayerSettings.companyName="TianZhang";
        PlayerSettings.fullScreenMode=FullScreenMode.Windowed;
        PlayerSettings.defaultScreenWidth=1120;
        PlayerSettings.defaultScreenHeight=760;
        PlayerSettings.resizableWindow=true;
        PlayerSettings.runInBackground=true;
        PlayerSettings.MTRendering=true;
        PlayerSettings.SplashScreen.showUnityLogo=false;
        QualitySettings.SetQualityLevel(2);
        Directory.CreateDirectory("Assets/Resources");
        foreach(var shaderName in new[]{"Standard","VRM10/MToon10","UniGLTF/UniUnlit"}) {
            var shader=Shader.Find(shaderName);
            if(shader==null)throw new Exception("Shader missing: "+shaderName);
            var matPath="Assets/Resources/"+shaderName.Replace('/','_')+".mat";
            if(!AssetDatabase.LoadAssetAtPath<Material>(matPath))AssetDatabase.CreateAsset(new Material(shader),matPath);
        }
        AssetDatabase.SaveAssets();
        var report=BuildPipeline.BuildPlayer(new[]{scenePath},"Player/SleeveAB.exe",BuildTarget.StandaloneWindows64,BuildOptions.None);
        if(report.summary.result!=BuildResult.Succeeded) throw new Exception(report.summary.result.ToString());
    }
}
